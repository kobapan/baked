<?php
Configure::write('Themes.ThemeCleanPaperBlue', array(
  'name' => __('Clean Paper Blue'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
