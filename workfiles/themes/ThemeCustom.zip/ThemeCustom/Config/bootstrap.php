<?php
Configure::write('Themes.ThemeCustom', array(
  'name' => __('カスタマイズ用テーマ'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
