<?php
Configure::write('Themes.ThemeTrustOrange', array(
  'name' => __('Trust Orange'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
