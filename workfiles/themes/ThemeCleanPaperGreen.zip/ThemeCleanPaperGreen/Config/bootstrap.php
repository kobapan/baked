<?php
Configure::write('Themes.ThemeCleanPaperGreen', array(
  'name' => __('Clean Paper Green'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
