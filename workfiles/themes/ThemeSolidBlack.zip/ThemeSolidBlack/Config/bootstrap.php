<?php
Configure::write('Themes.ThemeSolidBlack', array(
  'name' => __d('ThemeSolid', 'Solid Black'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
