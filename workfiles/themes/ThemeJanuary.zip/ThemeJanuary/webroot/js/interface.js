$(function(){
  $('#show-slider').sidr({
    name: 'sidr-slider',
    source: '#slider-navigation'
  });
});
