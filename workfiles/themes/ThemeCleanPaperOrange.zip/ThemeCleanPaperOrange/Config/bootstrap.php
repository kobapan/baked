<?php
Configure::write('Themes.ThemeCleanPaperOrange', array(
  'name' => __('Clean Paper Orange'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
