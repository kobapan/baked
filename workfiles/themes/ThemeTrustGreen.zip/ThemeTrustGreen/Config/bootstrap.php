<?php
Configure::write('Themes.ThemeTrustGreen', array(
  'name' => __('Trust Green'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
