<?php
Configure::write('Themes.ThemeTrustBlack', array(
  'name' => __('Trust Black'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
