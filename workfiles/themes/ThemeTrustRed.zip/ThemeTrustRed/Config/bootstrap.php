<?php
Configure::write('Themes.ThemeTrustRed', array(
  'name' => __('Trust Red'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
