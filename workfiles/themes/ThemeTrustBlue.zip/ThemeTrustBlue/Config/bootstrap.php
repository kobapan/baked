<?php
Configure::write('Themes.ThemeTrustBlue', array(
  'name' => __('Trust Blue'),
  'author' => 'bakedcms.org',
  'url' => 'http://bakedcms.org/',
  'support' => array(
    'pc'     => TRUE,
    'mobile' => FALSE,
  ),
));
